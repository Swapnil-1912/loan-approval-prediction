import streamlit as st
import pandas as pd
import joblib

st.set_page_config(
    page_title="Loan Approval Prediction",
    page_icon="🏦",
    layout="centered"
)

@st.cache_resource
def load_model():
    model = joblib.load("loan_model.joblib")
    feature_columns = joblib.load("feature_columns.joblib")
    return model, feature_columns

try:
    model, feature_columns = load_model()
except Exception as error:
    st.error(f"Unable to load the trained model: {error}")
    st.stop()

st.title("🏦 Loan Approval Prediction")
st.write("Enter the applicant details to obtain a machine learning prediction.")
st.info("This application provides an educational prediction, not an actual bank lending decision.")

with st.form("loan_prediction_form"):
    st.subheader("Applicant Information")
    gender = st.selectbox("Gender", ["Male", "Female"])
    married = st.selectbox("Marital Status", ["Yes", "No"])
    dependents = st.selectbox("Number of Dependents", ["0", "1", "2", "3+"])
    education = st.selectbox("Education", ["Graduate", "Not Graduate"])
    self_employed = st.selectbox("Self Employed", ["Yes", "No"])
    applicant_income = st.number_input("Applicant Income", min_value=0, value=5000)
    coapplicant_income = st.number_input("Co-applicant Income", min_value=0, value=0)
    loan_amount = st.number_input("Loan Amount", min_value=0, value=150)
    loan_term = st.number_input("Loan Term (months)", min_value=1, value=360)
    credit_history = st.selectbox("Credit History", [1.0, 0.0])
    property_area = st.selectbox("Property Area", ["Urban", "Semiurban", "Rural"])
    submit = st.form_submit_button("Predict Loan Status")

if submit:
    applicant = {
        "Gender": gender,
        "Married": married,
        "Dependents": dependents,
        "Education": education,
        "Self_Employed": self_employed,
        "ApplicantIncome": applicant_income,
        "CoapplicantIncome": coapplicant_income,
        "LoanAmount": loan_amount,
        "Loan_Amount_Term": loan_term,
        "Credit_History": credit_history,
        "Property_Area": property_area
    }
    
    input_df = pd.DataFrame([applicant])
    input_df = input_df.reindex(columns=feature_columns)
    
    try:
        prediction = model.predict(input_df)[0]
        st.subheader("Prediction Result")
        
        if str(prediction).strip().upper() in ["Y", "YES", "APPROVED", "1"]:
            st.success("Predicted result: Loan Approved")
        else:
            st.warning("Predicted result: Loan Not Approved")
            
        if hasattr(model, "predict_proba"):
            probabilities = model.predict_proba(input_df)[0]
            st.write("Model probability estimates")
            probability_df = pd.DataFrame({
                "Class": model.classes_,
                "Probability (%)": probabilities * 100
            })
            st.dataframe(probability_df, hide_index=True, use_container_width=True)
    except Exception as error:
        st.error("Prediction failed. Check whether the input fields match the features used during model training.")
        st.exception(error)